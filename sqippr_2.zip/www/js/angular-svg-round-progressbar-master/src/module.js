'use strict';

angular.module('angular-svg-round-progressbar', []);
