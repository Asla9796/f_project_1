var express = require('express');
var app = express();
var request = require('request');

var bodyParser = require('body-parser');

app.use( bodyParser.json() );       // to support JSON-encoded bodies
app.use(bodyParser.urlencoded({     // to support URL-encoded bodies
  extended: true
})); 

app.post('http://127.0.0.1:31999/project_3_hasura/www/index.html#/tab/successfulPayment', function (req, res) {
  var paymentRes = req.body;
  
  request.post({url:'http://data.lingerie91.hasura-app.io/api/1/tables/orders/select', 
                data: {"columns": ["hash_string"],
                        "where": {"timestamp": paymentRes.txnid}
                }}, 
    
    function optionalCallback(error, response, body) {
      if (error) {
        return console.error('error', error);
      }
      console.log('successful response', body);
      var str = body.hash_string;
      var splitString = str.split(); 
      var reverseArray = splitString.reverse(); 
      var addStatus = reverseArray.splice();
      
    });
});

app.listen(3000, function () {
  console.log('Example app listening on port 3000!');
});
