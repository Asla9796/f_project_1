AngularJS Photo Slider
====================

An AngularJS photo slider built using AngularJS animate and Greensock.

## Additional Resources

[Remastered Animation in AngularJS 1.2](http://www.yearofmoo.com/2013/08/remastered-animation-in-angularjs-1-2.html)

[Getting Started with the JavaScript Version of the GreenSock Animation Platform (GSAP)](https://www.greensock.com/get-started-js/)