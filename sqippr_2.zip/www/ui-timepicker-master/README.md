ui-timepicker
=============

A fancy timepicker (angular directive)

It is a time picker which looks like a round slider. 
